# Rescate Tempestad 0.2.0

Juego Android original de rescate lateral en helicóptero, con cuerda flexible y tornado. Español, recursos dibujados por código, offline, sin anuncios, compras, cuentas ni telemetría.

## Sincronización

Este commit incorpora los fuentes Java completos, pruebas, workflow y documentación que faltaban en GitHub. La configuración Android ya estaba en `6f3e6c9589e6ba62d1b815f98add7718c5b3b1ac`.

Los fuentes se recuperaron del texto y modificaciones registrados en la conversación de desarrollo. El ZIP y entorno originales no estaban disponibles en esta sesión; no se afirma igualdad binaria con aquel APK ni se han reconstruido informes de pruebas inexistentes. Ahora el repositorio conserva el código recuperado para futuras continuaciones sin depender del sistema de archivos temporal.

**Estado del producto: prototipo, no candidata de publicación.** El resultado local anterior registrado fue 35 pruebas JVM aprobadas y Lint con cero errores/cinco avisos. Las seis pruebas Android se compilaron, pero no se ejecutaron entonces. Consultar Actions para conocer resultados nuevos; subir un workflow no equivale a confirmar CI verde.

## Sistemas implementados

- Joystick, vuelo con inercia, terreno y daños.
- Cuerda de 14 nodos, torno, rescate y evacuación en BASE, cabina de tres plazas.
- Viento, lluvia y tornado móvil; seis operaciones con desbloqueos y estrellas.
- Guardado de misión activa cada diez segundos y al pausar, con historial de cuerda, esquema, límites, CRC32 y escritura atómica.
- Carga siempre pausada y descarte de guardados dañados sin borrar campaña.
- Efectos suaves y avisos sonoros sintetizados propios.

CRC32 detecta corrupción accidental, no autentica archivos ni cifra datos. El autoguardado periódico puede perder los últimos segundos ante una terminación forzada sin callback.

## Cómo jugar

Selecciona misión y CONTINUAR. Vuela con joystick izquierdo; BAJAR despliega cuerda y RECOGER la sube. Estabiliza el gancho junto a SOS, recoge hasta incorporar a la persona y regresa a BASE a poca altura y velocidad. BASE repara y reposta. El viento desplaza el gancho, de modo que situar el helicóptero exactamente sobre la persona no siempre basta.

## Compilar

JDK 17, SDK Android 36, Build Tools 35.0.0, Gradle 8.13, AGP 8.13.2. Mínimo API 26; objetivo API 36. Importar raíz en Android Studio o configurar ANDROID_HOME/local.properties.

Linux: `sh gradlew testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest bundleRelease`

Windows: `gradlew.bat testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest bundleRelease`

El bootstrap obtiene el wrapper oficial con SHA-256; la distribución Gradle también tiene checksum. Requiere curl/sha256sum en Linux o PowerShell en Windows. macOS puede usar Gradle 8.13 instalado o disponer de sha256sum.

APK: `app/build/outputs/apk/debug/app-debug.apk`, firmado solo para pruebas. AAB: `app/build/outputs/bundle/release/app-release.aab`, sin firma de publicación. No se incluye clave debug/release, SDK, caches ni vídeo.

## CI y entregas

[GitHub Actions](https://github.com/Stevengc360/Rescate-Tempestad/actions) tiene un workflow para construir APK/AAB, ejecutar JVM/Lint y después seis pruebas instrumentadas en emuladores API 29/35. En una ejecución satisfactoria el artefacto conserva builds e informes durante 30 días. No se ha verificado aquí la ejecución remota. La disponibilidad depende de permisos, cuotas y configuración de Actions.

## Documentación

- [Descripción del vídeo](docs/VIDEO.md)
- [Plan y arquitectura](docs/PLAN.md)
- [Validaciones y límites](docs/QA.md)
- [Estado de continuación](docs/STATUS.md)
- [Registro de cambios](CHANGELOG.md)

Pendientes: pruebas reales en dispositivo, arte/física de carga más rica, accesibilidad Canvas, rendimiento, balance humano y firma de distribución. No existe un agente desarrollando entre mensajes; Actions comprueba código, no programa funciones automáticamente.

Una build debug nueva puede llevar un certificado distinto al del APK previo. Si Android rechaza una actualización por firma, no desinstalar sin considerar que se perderán los datos locales. La beta necesita una clave estable custodiada fuera de git.
