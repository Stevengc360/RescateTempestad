# Recursos y privacidad

Proyecto privado, con código y geometría originales. Sin gráficos, música o voces extraídos del vídeo y sin incluir el adjunto. Sin permisos de red, SDK publicitarios, analítica, compras o cuentas. Progreso y misión activa permanecen en almacenamiento interno; backup desactivado en el manifiesto.

Gradle, Android y bibliotecas de pruebas mantienen sus licencias. El bootstrap obtiene el wrapper oficial verificado por SHA-256 y el SDK se instala aparte. No se establece licencia pública de redistribución para este repositorio privado.

APK debug: pruebas, no publicación. Bundle release: requiere firma privada de distribución antes de tienda. No subir claves, tokens, local.properties ni material del vídeo a git.
