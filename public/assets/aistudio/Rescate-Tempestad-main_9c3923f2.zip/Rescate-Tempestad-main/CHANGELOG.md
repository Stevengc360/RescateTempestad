# Cambios

## Sincronización de fuentes — 2026-11-09

- Recuperados de los textos y modificaciones de la conversación los cuatro fuentes de producción y dos de pruebas de 0.2.0.
- Incorporados en una operación motor, vista, ciclo de vida, persistencia, 35 tests JVM, 6 tests Android, workflow y documentación.
- Actualizado estado remoto frente a la sincronización antes incompleta.
- No se afirma verificación de igualdad binaria con el ZIP anterior ni se recrean logs/XML originales no disponibles.
- CI configurado para producir evidencias nuevas; resultado remoto todavía no verificado durante la subida.

## 0.2.0 — desarrollo anterior

- Reconstrucción desde la especificación de 0.1.0, al no persistir aquel entorno.
- Snapshots de misión versionados con CRC32, rangos e historial de cuerda, escritura atómica y reanudación pausada.
- Autoguardado cada diez segundos y al pausar/salir.
- 35 regresiones JVM; seis misiones ganables mediante controles y restauraciones periódicas.
- Seis pruebas instrumentadas compiladas, pendientes de ejecución.
- Primer commit de configuración autorizado; segunda subida no autorizada entonces y no eludida.
