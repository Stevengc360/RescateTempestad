@echo off
setlocal
set "JAR=%~dp0gradle\wrapper\gradle-wrapper.jar"
powershell -NoProfile -Command "$p='%JAR%';$h='81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f';if(!(Test-Path $p)){$t=$p+'.tmp';Invoke-WebRequest 'https://raw.githubusercontent.com/gradle/gradle/v8.13.0/gradle/wrapper/gradle-wrapper.jar' -OutFile $t;if((Get-FileHash $t -Algorithm SHA256).Hash.ToLower() -ne $h){Remove-Item $t;exit 1};Move-Item $t $p};if((Get-FileHash $p -Algorithm SHA256).Hash.ToLower() -ne $h){exit 1}"
if errorlevel 1 exit /b 1
if defined JAVA_HOME (set "JAVA=%JAVA_HOME%\bin\java.exe") else (set "JAVA=java")
"%JAVA%" -Dfile.encoding=UTF-8 -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
