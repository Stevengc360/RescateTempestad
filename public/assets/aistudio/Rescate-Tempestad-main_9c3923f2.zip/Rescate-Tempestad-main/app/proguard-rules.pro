# No reflection-based persistence; snapshots have an explicit binary schema.
