package com.stevengc360.rescatetempestad;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.ViewGroup;
import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class DeviceTest {
    static GameView view(MainActivity a){return (GameView)((ViewGroup)a.findViewById(android.R.id.content)).getChildAt(0);}
    static void tap(GameView v,float x,float y){long t=SystemClock.uptimeMillis();MotionEvent d=MotionEvent.obtain(t,t,MotionEvent.ACTION_DOWN,v.screenX(x),v.screenY(y),0),u=MotionEvent.obtain(t,t+20,MotionEvent.ACTION_UP,v.screenX(x),v.screenY(y),0);try{v.onTouchEvent(d);v.onTouchEvent(u);}finally{d.recycle();u.recycle();}}
    static void firstMission(GameView v){tap(v,140,320);assertFalse(v.inMenu());assertNotNull(v.state());assertEquals(GameEngine.Phase.PAUSED,v.state().phase);tap(v,400,425);assertEquals(GameEngine.Phase.RUNNING,v.state().phase);}
    static void event(GameView v,int action,int[] ids,float[] xs,float[] ys){
        MotionEvent.PointerProperties[] props=new MotionEvent.PointerProperties[ids.length];MotionEvent.PointerCoords[] coords=new MotionEvent.PointerCoords[ids.length];
        for(int i=0;i<ids.length;i++){props[i]=new MotionEvent.PointerProperties();props[i].id=ids[i];props[i].toolType=MotionEvent.TOOL_TYPE_FINGER;coords[i]=new MotionEvent.PointerCoords();coords[i].x=v.screenX(xs[i]);coords[i].y=v.screenY(ys[i]);coords[i].pressure=1;coords[i].size=1;}
        long t=SystemClock.uptimeMillis();MotionEvent e=MotionEvent.obtain(t,t,action,ids.length,props,coords,0,0,1,1,0,0,0,0);try{v.onTouchEvent(e);}finally{e.recycle();}
    }
    @Test public void opensMenu(){try(ActivityScenario<MainActivity> s=ActivityScenario.launch(MainActivity.class)){s.onActivity(a->assertTrue(view(a).inMenu()));}}
    @Test public void twoPointerIdsRemainIndependent(){try(ActivityScenario<MainActivity> s=ActivityScenario.launch(MainActivity.class)){s.onActivity(a->{GameView v=view(a);firstMission(v);event(v,MotionEvent.ACTION_DOWN,new int[]{7},new float[]{175},new float[]{647});event(v,MotionEvent.ACTION_POINTER_DOWN|(1<<MotionEvent.ACTION_POINTER_INDEX_SHIFT),new int[]{7,19},new float[]{175,980},new float[]{647,650});assertTrue(v.inputX()>.5);assertEquals(1,v.winchInput());event(v,MotionEvent.ACTION_POINTER_UP,new int[]{7,19},new float[]{175,980},new float[]{647,650});assertEquals(0,v.inputX(),0);assertEquals(1,v.winchInput());event(v,MotionEvent.ACTION_UP,new int[]{19},new float[]{980},new float[]{650});assertEquals(0,v.winchInput());});}}
    @Test public void cancelClearsBothControls(){try(ActivityScenario<MainActivity> s=ActivityScenario.launch(MainActivity.class)){s.onActivity(a->{GameView v=view(a);firstMission(v);event(v,MotionEvent.ACTION_DOWN,new int[]{4},new float[]{175},new float[]{647});event(v,MotionEvent.ACTION_CANCEL,new int[]{4},new float[]{175},new float[]{647});assertEquals(0,v.inputX(),0);assertEquals(0,v.winchInput());});}}
    @Test public void recreationPreservesExactMissionPosition(){try(ActivityScenario<MainActivity> s=ActivityScenario.launch(MainActivity.class)){s.onActivity(a->{GameView v=view(a);firstMission(v);v.state().x=777;v.state().y=230;v.suspend();});s.recreate();s.onActivity(a->{GameView v=view(a);assertTrue(v.inMenu());tap(v,300,225);assertFalse(v.inMenu());assertEquals(777,v.state().x,0);assertEquals(230,v.state().y,0);assertEquals(GameEngine.Phase.PAUSED,v.state().phase);});}}
    @Test public void backgroundPausesWithoutAutoResume(){try(ActivityScenario<MainActivity> s=ActivityScenario.launch(MainActivity.class)){s.onActivity(a->firstMission(view(a)));s.moveToState(Lifecycle.State.CREATED);s.moveToState(Lifecycle.State.RESUMED);s.onActivity(a->{GameView v=view(a);assertEquals(GameEngine.Phase.PAUSED,v.state().phase);assertEquals(0,v.inputX(),0);});}}
    @Test public void corruptSaveDoesNotCrashOrEraseCampaign(){try(ActivityScenario<MainActivity> s=ActivityScenario.launch(MainActivity.class)){s.onActivity(a->{GameStore st=new GameStore(a);st.clear();try(java.io.FileOutputStream f=a.openFileOutput("active-mission-v1.bin",0)){f.write(new byte[]{1,2,3});}catch(java.io.IOException e){throw new AssertionError(e);}int unlock=st.unlocked();assertNull(st.load());assertEquals(unlock,st.unlocked());assertFalse(st.warning.isEmpty());});}}
}
