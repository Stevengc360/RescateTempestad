package com.stevengc360.rescatetempestad;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.MotionEvent;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class AndroidRegressionTest {
    private Context context;
    private SharedPreferences prefs;
    @Before public void reset(){context=InstrumentationRegistry.getInstrumentation().getTargetContext();prefs=context.getSharedPreferences("campaign_v1",0);assertTrue(prefs.edit().clear().commit());new GameStore(context).clear();}
    private void ui(Runnable test){InstrumentationRegistry.getInstrumentation().runOnMainSync(test);}
    private static void tap(GameView v,float x,float y){long t=SystemClock.uptimeMillis();MotionEvent d=MotionEvent.obtain(t,t,MotionEvent.ACTION_DOWN,v.screenX(x),v.screenY(y),0),u=MotionEvent.obtain(t,t+10,MotionEvent.ACTION_UP,v.screenX(x),v.screenY(y),0);try{v.onTouchEvent(d);v.onTouchEvent(u);}finally{d.recycle();u.recycle();}}
    private static void launch(GameView v){tap(v,140,320);tap(v,400,425);assertEquals(GameEngine.Phase.RUNNING,v.state().phase);}
    @Test public void invalidSavePreservesPreviousCheckpoint(){ui(()->{GameStore st=new GameStore(context);GameEngine good=new GameEngine(0);good.x=777;assertTrue(st.save(good));GameEngine bad=new GameEngine(1);bad.health=101;assertFalse(st.save(bad));GameEngine restored=st.load();assertNotNull(restored);assertEquals(0,restored.index);assertEquals(777,restored.x,0);});}
    @Test public void successfulSaveClearsOldError(){ui(()->{GameStore st=new GameStore(context);GameEngine bad=new GameEngine(0);bad.x=Double.NaN;assertFalse(st.save(bad));assertFalse(st.warning.isEmpty());assertTrue(st.save(new GameEngine(0)));assertEquals("",st.warning);});}
    @Test public void nonVictoryCannotUnlockMission(){ui(()->{GameStore st=new GameStore(context);assertTrue(st.save(new GameEngine(0)));st.complete(new GameEngine(0));assertEquals(0,st.unlocked());assertEquals(0,st.stars(0));assertNotNull(st.load());});}
    @Test public void forgedVictoryCannotUnlockMission(){ui(()->{GameStore st=new GameStore(context);GameEngine e=new GameEngine(0);e.phase=GameEngine.Phase.WON;e.delivered=1;st.complete(e);assertEquals(0,st.unlocked());assertEquals(0,st.stars(0));});}
    @Test public void mismatchedPreferenceTypesDoNotCrash(){ui(()->{assertTrue(prefs.edit().putString("unlocked","bad").putString("stars_0","bad").putString("calm","bad").putString("sound","bad").commit());GameStore st=new GameStore(context);assertEquals(0,st.unlocked());assertEquals(0,st.stars(0));assertFalse(st.calm());assertTrue(st.sound());st.toggleSound();st.toggleCalm();assertFalse(st.sound());assertTrue(st.calm());});}
    @Test public void letterboxIsNotJoystick(){ui(()->{GameView v=new GameView(context);try{v.layout(0,0,1800,720);launch(v);long t=SystemClock.uptimeMillis();MotionEvent d=MotionEvent.obtain(t,t,MotionEvent.ACTION_DOWN,5,v.screenY(647),0);try{v.onTouchEvent(d);}finally{d.recycle();}assertEquals(0,v.inputX(),0);assertEquals(0,v.winchInput());}finally{v.release();}});}
    @Test public void suspendingMenuCannotOverwriteNewerCheckpoint(){ui(()->{GameView v=new GameView(context);try{v.layout(0,0,1280,720);launch(v);v.back();v.back();assertTrue(v.inMenu());GameStore st=new GameStore(context);GameEngine newer=new GameEngine(1);newer.x=888;assertTrue(st.save(newer));tap(v,100,550);v.suspend();GameEngine restored=st.load();assertNotNull(restored);assertEquals(1,restored.index);assertEquals(888,restored.x,0);}finally{v.release();}});}
    @Test public void settingsSurviveSuspensionInMenu(){ui(()->{GameView v=new GameView(context);try{v.layout(0,0,1280,720);launch(v);v.back();v.back();tap(v,100,550);tap(v,400,550);v.suspend();GameStore st=new GameStore(context);assertFalse(st.sound());assertTrue(st.calm());}finally{v.release();}});}
    @Test public void dangerLabelStaysInsideViewport(){ui(()->{GameView v=new GameView(context);try{Paint p=new Paint();p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(15);for(double x:new double[]{-900,-1,0,640,1260,1280,2200}){float left=v.dangerLabelX(x);assertTrue(left>=12);assertTrue(left+p.measureText(v.dangerLabelText(x))<=1268.01f);}assertEquals("PELIGRO >",v.dangerLabelText(1600));assertEquals("< PELIGRO",v.dangerLabelText(-20));}finally{v.release();}});}
    @Test public void loadedMissionAlwaysPaused(){ui(()->{GameStore st=new GameStore(context);GameEngine e=new GameEngine(2);assertTrue(st.save(e));assertEquals(GameEngine.Phase.RUNNING,e.phase);assertEquals(GameEngine.Phase.PAUSED,st.load().phase);});}
    @Test public void legitimateVictoryUnlocksNextMission(){ui(()->{GameStore st=new GameStore(context);GameEngine e=new GameEngine(0);e.people.get(0).status=GameEngine.Status.SAVED;e.delivered=1;e.phase=GameEngine.Phase.WON;st.complete(e);assertEquals(1,st.unlocked());assertEquals(3,st.stars(0));assertNull(st.load());});}
}
