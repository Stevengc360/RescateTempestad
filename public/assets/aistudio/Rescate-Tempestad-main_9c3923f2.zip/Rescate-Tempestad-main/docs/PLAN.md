# Plan de programación

## Objetivo

Juego Android original de rescate 2D lateral en helicóptero con cuerda flexible, lluvia, viento, relieve y tornado. Se excluye toda interfaz de Facebook y no se extraen sus recursos gráficos o sonoros. Combustible, BASE, campaña, estrellas, controles y guardado son decisiones propias, no mecánicas demostradas por el clip.

## Arquitectura

| Archivo | Responsabilidad |
|---|---|
| GameEngine.java | Simulación fija, terreno, vuelo, cuerda, personas, tormenta, reglas y esquema de snapshot |
| GameView.java | Render Canvas, cámara, joystick, torno, HUD, reloj y menús |
| MainActivity.java | Ciclo de vida, foco, pausa, barras de sistema y navegación Atrás |
| GameStore.java | Campaña/ajustes y escritura atómica de misión activa |
| GameEngineTest.java | 35 regresiones JVM |
| DeviceTest.java | 6 pruebas Android de integración |
| android.yml | Build/JVM/Lint y emuladores 29/35 en CI |

Java 17, Gradle 8.13 y AGP 8.13.2 fijados; compile/target API 36, mínimo API 26. La simulación trabaja a 60 pasos/s, que no representa una medición de FPS en dispositivo. Un único hilo UI muta estado, sin servicios remotos.

## Sistemas

Vuelo arcade con aceleración, inercia, amortiguación, velocidad limitada, inclinación visual y contacto con terreno. Colisiones rápidas dañan y BASE repara/reposta. Cuerda de 14 nodos por integración Verlet y restricciones, longitud 65–245 unidades, suelo, tensión y repuesto. No hay todavía masa de rescatados físicamente acoplada al helicóptero.

Personas en estados esperando/colgando/a bordo/salvadas/perdidas. Enganche de proximidad a velocidad moderada; recogida hasta longitud corta; cabina de tres plazas; entrega sobre BASE lenta y a baja altura. Una pérdida obliga a reintentar: todavía no hay caídas articuladas recuperables.

Lluvia visual, viento variable y tornado móvil con atracción, elevación y daño. Cámara horizontal suave, capas de fondo, HUD y efectos suaves. Los tonos breves son originales; audio ambiental completo pendiente.

## Campaña

| Operación | Personas | Tiempo inicial |
|---|---:|---:|
| Primer rescate | 1 | 240 s |
| Lluvia lateral | 2 | 250 s |
| El embudo | 3 | 300 s |
| Cuerda al límite | 4 | 340 s |
| Noche de evacuación | 5 | 390 s |
| Última llamada | 6 | 440 s |

Valores propios de diseño, no del vídeo. Desbloqueo secuencial; una estrella por completar, otra por al menos 60% de integridad y otra por al menos 25% del tiempo restante. Debe validarse con humanos, además del piloto automatizado.

## Guardado

Binario esquema 1 con cabecera, misión/fase, recursos/relojes, tornado, personas y posiciones presentes/previas de cuerda. CRC32 y límite de 16 KiB, validaciones de rangos, finitud e invariantes. CRC32 detecta corrupción accidental, no ofrece autenticación ni cifrado.

AtomicFile en almacenamiento interno, guardado cada diez segundos y al pausar/cambiar de app; siempre reanuda pausado. Guardado inválido descartado sin borrar campaña. Puede perderse el intervalo final si se mata el proceso sin callback. Nueva misión reemplaza checkpoint anterior.

## Fases

| Fase | Puerta de aceptación | Estado de producto |
|---|---|---|
| Base y fuentes | Proyecto completo recuperable en GitHub | Fuentes sincronizados en este cambio |
| Motor y snapshots | Misiones y recuperación comprobadas | Resultado local anterior aprobado; repetir en CI |
| Integración Android | Pruebas multitáctiles, interrupciones y persistencia ejecutadas | Pendiente de resultados reales |
| Estabilización | API 26/29/35/36, pantallas y sesiones largas | Pendiente |
| Fidelidad | Carga, caídas, arte y sonidos propios refinados | Pendiente |
| Beta | Campaña ganable y agradable para humanos | Pendiente |
| Publicación | Firma privada, políticas, ficha y aprobación | Pendiente |

## Intervención mínima

Tomar decisiones técnicas reversibles sin consultar cada ajuste; reservar para Steven permisos, costes, claves, publicación y prueba cerca de beta. Bloqueantes: crash/ANR, estado no finito, misión imposible, entradas atascadas, corrupción de campaña o build inválido. No publicar hasta resolverlos. GitHub Actions verifica código, no programa ni supervisa autónomamente nuevas funciones.
