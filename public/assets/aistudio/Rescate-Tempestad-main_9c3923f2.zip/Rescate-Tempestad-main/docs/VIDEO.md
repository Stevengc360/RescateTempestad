# Vídeo de referencia

Fuente: `Screen_Recording_20261105_100348_Facebook.mp4`, facilitado por Steven. Se conserva aquí la descripción documentada en la conversación inicial; no se ha vuelto a inspeccionar el vídeo durante la sincronización. Duración documentada: aproximadamente 15,19 segundos; marcas temporales aproximadas.

## Apariencia

Juego bidimensional lateral, nocturno y de alto contraste. Negro y gris oscuro dominan el escenario; helicóptero, cuerda y figuras humanas se dibujan con trazos blancos o marfil. Hay acentos rojizos breves cerca del aparato. El acabado parece esbozado y no fotorrealista.

Cabina redondeada, cola lateral, patines y rotor; debajo cuelga cuerda o escala flexible con marcas/nudos que se curva al moverse. Personas muy pequeñas con extremidades finas esperan en un saliente/plataforma. El relieve presenta colinas de perfiles claros y capas oscuras al fondo. La lluvia cae en trazos oblicuos.

El tornado es un gran embudo de bandas curvas en espiral, estrecho abajo y ancho arriba; domina el encuadre al acercarse el helicóptero. Aparato, terreno y embudo cambian de posición relativa durante el seguimiento de la acción.

## Secuencia aproximada

| Momento | Observación documentada |
|---|---|
| 0–2 s | Helicóptero sobre elevación; cuerda descendida hacia personas y pequeño saliente, con lluvia intensa |
| 2–5 s | Separación del saliente y desplazamiento sobre relieve; cuerda inclinada y oscilante |
| 5–8 s | Embudo ocupa el plano; aparato, cuerda y figuras cerca o dentro de bandas de viento |
| 8–12 s | Cambios fuertes de inclinación, figuras o fragmentos separados y acentos rojizos; cuerda menos distinguible |
| 12–15,19 s | Salida lateral del centro del embudo y nuevo relieve con personas; sin resultado inequívoco |

## Límites

La transcripción disponible recoge tres exclamaciones breves en inglés relacionadas con no poder aguantar, quedarse cerca y la cuerda. No identifica con certeza si las voces pertenecen al juego. La aparente separación de figuras sugiere rescate fallido, pero no prueba algoritmo de rotura, enganche ni pérdida del agarre.

No pueden deducirse botones, economía, combustible, guardado, campaña ni lugar de entrega; son diseño posterior. La orientación vertical corresponde a la grabación de Facebook, no demuestra orientación nativa del juego.

## Excluido

Barras del teléfono, navegación de Facebook, perfil, reacciones, comentarios, etiquetas, texto promocional, caja de comentarios y texto explicativo superpuesto. No se redistribuyen vídeo, marcas, voces, música ni gráficos ajenos. El nuevo proyecto usa código, geometría, nombre provisional y sonidos propios.
