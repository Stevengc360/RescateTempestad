# Instalar la versión de pruebas

## Descarga

- [Release de pruebas Android](https://github.com/Stevengc360/Rescate-Tempestad/releases/tag/pruebas-android).
- [APK directo una vez publicado](https://github.com/Stevengc360/Rescate-Tempestad/releases/download/pruebas-android/Rescate-Tempestad-pruebas.apk).
- [Ejecuciones de entrega del APK](https://github.com/Stevengc360/Rescate-Tempestad/actions/workflows/apk.yml).

Son enlaces privados: abre GitHub con la cuenta que tiene acceso al repositorio. La Release no existe hasta que una ejecución termina de compilar y publicar; un enlace escrito aquí no confirma por sí solo disponibilidad.

Si no hay Release, abre la ejecución de **APK descargable para probar**. Si compiló pero no pudo publicar por permisos, descarga el artefacto **APK-instalable-…**, extrae el ZIP y abre el archivo `.apk`. No intentes instalar el ZIP ni un AAB.

## Android

Requiere Android 8.0/API 26 o posterior. Al abrir el APK puede ser necesario permitir instalaciones desde el navegador/gestor usado; concede ese permiso solo para instalar este archivo y desactívalo después. No desactives Play Protect.

Es un APK debug de prototipo. Su firma se verifica durante la entrega; eso no demuestra ausencia de fallos ni pruebas completas en dispositivo. Si una versión anterior tiene otra firma, no se actualizará sobre ella. No desinstales sin asumir la pérdida de progreso local.

## Qué se ha corregido en la entrega

La compilación del APK se separa de Lint, AAB y emuladores para que esos trabajos no bloqueen la obtención del instalador. El APK se conserva como artefacto antes de intentar publicarlo; se añade SHA-256, información de build y firma. La publicación usa permiso contents:write solo en el trabajo de entrega y solo en main. El otro workflow sigue ejecutando las verificaciones completas.

El enlace `pruebas-android` es una entrega móvil que se actualiza: consulta build.txt y notas de Release para el commit real; el tag inicial no identifica todos los binarios posteriores. La caché del certificado debug puede caducar y no sustituye una clave de beta/producción custodiada por el propietario.
