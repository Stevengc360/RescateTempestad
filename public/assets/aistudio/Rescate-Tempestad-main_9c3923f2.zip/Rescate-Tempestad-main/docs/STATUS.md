# Estado de Rescate Tempestad — revisión 0.2.1

## Cambios sincronizados

Correcciones de reglas terminales y persistencia en `a01db6c4cb13536f805a3447718ba9c78204de9e`, vista y regresiones JVM en `e76c96e65f98d4da7fc90dcd9ec5c9dfd4d15be4`, regresiones Android y versión 0.2.1/código 3 en `f7a4525387947b45774cd559716a2101e79c5928`. Se verificó mediante lectura remota que el motor y GameStore corregidos están presentes en main.

- Salud, combustible, tiempo agotado y personas perdidas prevalecen sobre reparación y entrega en BASE.
- La cuerda que se rompe deja de recoger personas en ese paso.
- Los límites horizontales eliminan velocidad dirigida fuera del mapa, sin impedir volver hacia dentro.
- El estado se valida antes de abrir la escritura atómica: un guardado activo inválido conserva el checkpoint anterior.
- Un guardado correcto limpia el aviso de error; una misión no ganada o inconsistente no desbloquea campaña.
- Las preferencias con tipos inesperados vuelven a valores seguros en lugar de lanzar ClassCastException.
- Suspender en menú ya no vuelve a guardar la antigua partida. Los ajustes quedan en preferencias y se consultan directamente.
- Los contactos iniciales en franjas negras no accionan controles. El temporizador de autoguardado se reinicia al iniciar o continuar.
- PELIGRO se mantiene dentro del ancho útil e indica dirección cuando el tornado queda fuera; los avisos de almacenamiento se muestran en menú y partida.

## Verificado en esta revisión

Compilación Java 17 y ejecución directa con JUnit 4.13.2: **45 pruebas aprobadas, 0 fallos**, 35 originales y 10 nuevas del motor. El log y hashes están en `docs/evidence/0.2.1/`. El hash Git del motor ejecutado coincide con el leído de main: `607cf2970e8b0df7dcfd50f846b3add56066c9d8`.

Las pruebas incluyen las seis misiones completadas mediante controles simulados, las seis con restauraciones periódicas, determinismo del snapshot, rechazo de corrupción/truncado y estrés de 216000 pasos. Esto demuestra rutas programáticas posibles, no balance humano ni diversión.

Se añadieron **11 pruebas instrumentadas Android** de persistencia, preferencias, menú, franjas laterales y aviso de peligro. No se ejecutaron en dispositivo/emulador en esta revisión; no se suman a las 45 aprobadas. Se conservan además las pruebas instrumentadas anteriores.

## No verificado todavía

- No se ejecutó una compilación Android completa ni Lint ni se generó un APK nuevo en esta revisión.
- El workflow está configurado para JVM/Lint/APK/AAB y después emuladores API 29/35, pero su resultado remoto no se ha obtenido con la conexión disponible. Workflow configurado no significa CI aprobado.
- No se trasladan los resultados ni los recuentos de la evaluación temporal anterior como evidencia de este commit.
- Sin prueba humana de los controles, revisión visual en dispositivo, perfilado de rendimiento ni firma de distribución.

## Próximos pasos

1. Consultar Actions del último commit, resolver compilación/Lint y ejecutar emuladores API 29/35.
2. Verificar guardado con disco lleno e interrupción; la escritura es síncrona en UI, pendiente de perfilado.
3. Añadir API 26/36, probar multitáctil, pérdida de foco y muerte de proceso en Android real; capturar imágenes reales.
4. Exponer controles individuales a TalkBack: Canvas aún no tiene nodos por elemento.
5. Revisar dificultad, arte y audio con recursos propios. Un piloto automático no sustituye una prueba de juego humana.
6. Pedir intervención de Steven cerca de beta para sensaciones y estética. Firma, gastos y publicación siguen requiriendo aprobación explícita.

## Decisiones mantenidas

Español, privado, offline, sin anuncios ni compras. Nombre provisional Rescate Tempestad. No se almacenan claves ni recursos extraídos del vídeo. No hay desarrollo autónomo entre mensajes.
