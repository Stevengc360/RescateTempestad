# Validación de Rescate Tempestad 0.2.0

## Evidencia local anterior

En la sesión de desarrollo anterior se ejecutó `testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest bundleRelease` con Java 17, Gradle 8.13 y AGP 8.13.2: BUILD SUCCESSFUL. Su salida registrada indica 35 pruebas JVM, 0 fallos, 0 errores, 0 omitidas, y Lint con 0 errores/5 avisos.

Estos son resultados de aquella sesión, no una ejecución nueva del commit sincronizado. Sus XML/logs originales y el ZIP ya no están disponibles en el entorno actual; por eso no se han creado archivos que aparenten ser aquellos informes. Los resultados nuevos deben proceder de una ejecución real de CI.

## Cobertura del código recuperado

35 tests JVM: límites de simulación, pausa, estados terminales, seis misiones completadas con entradas del motor, rescate completo, snapshots de fases de rescate, continuación determinista, seis misiones con restauraciones periódicas, corrupción byte a byte, truncación, versiones inválidas, finitud, conteos y estados imposibles.

Estrés: 216.000 pasos entre seis configuraciones con entradas reproducibles, reinicios tras fin de partida y restauraciones periódicas. No equivale a horas de juego visual ni mide FPS, temperatura o consumo.

Seis tests instrumentados: menú, dos IDs de dedo independientes, cancelación, recreación y coordenadas restauradas, pausa en fondo y descarte de guardado corrupto conservando campaña. Estaban compilados, no ejecutados. Ahora se configura CI para su ejecución; puede detectar fallos todavía pendientes.

## Pendiente

- Resultados remotos del workflow actual y emuladores.
- Instalación física y controles/audio/márgenes reales.
- Muerte real de proceso y fallos de disco con escritura atómica.
- Rendimiento y sesiones prolongadas.
- Accesibilidad por elementos Canvas y pantallas tablet/vertical.
- Balance humano de seis operaciones.
- Física de carga, caídas y acabado artístico.
- Clave privada de distribución y revisión previa de publicación.

La firma debug puede diferir de APK anteriores generados en otro entorno. No recomendar desinstalación sin advertir la pérdida de datos locales. El juego no está validado para publicar ni se promete ausencia de fallos.
