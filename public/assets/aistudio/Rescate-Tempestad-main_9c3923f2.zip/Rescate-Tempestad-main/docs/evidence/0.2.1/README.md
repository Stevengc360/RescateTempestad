# Evidencia JVM 0.2.1

Ejecución local real de los archivos identificados abajo; no es un resultado de GitHub Actions ni de Android.

## Entorno

- OpenJDK Zulu 17.0.17+10-LTS.
- Compilación con javac --release 17 -encoding UTF-8.
- JUnit 4.13.2 y Hamcrest Core 1.3.

## Comandos reproducibles

Desde la raíz del repositorio, con las dos dependencias JUnit/Hamcrest disponibles fuera del árbol:

```sh
mkdir -p /tmp/rt-test-classes
javac --release 17 -encoding UTF-8 -cp "$JUNIT_JAR:$HAMCREST_JAR" \
  -d /tmp/rt-test-classes \
  app/src/main/java/com/stevengc360/rescatetempestad/GameEngine.java \
  app/src/test/java/com/stevengc360/rescatetempestad/GameEngineTest.java \
  app/src/test/java/com/stevengc360/rescatetempestad/EngineRegressionTest.java
java -cp "/tmp/rt-test-classes:$JUNIT_JAR:$HAMCREST_JAR" org.junit.runner.JUnitCore \
  com.stevengc360.rescatetempestad.GameEngineTest \
  com.stevengc360.rescatetempestad.EngineRegressionTest
```

También se pueden ejecutar desde Android/Gradle mediante el workflow existente. No se ha confirmado ese resultado remoto.

## Identidad exacta

Hashes Git blob (cabecera `blob <bytes>\0` y contenido):

| Archivo | SHA-1 Git blob |
| --- | --- |
| GameEngine.java | 607cf2970e8b0df7dcfd50f846b3add56066c9d8 |
| GameEngineTest.java | 718bbe934d615fe02fa94fe6ef8813a63729eb71 |
| EngineRegressionTest.java | 03e1dfcf7afa422f4ab5f3e0df1645d50628e714 |

Resultado: 45 pruebas, 0 fallos. Log en `junit-core.txt`. Las pruebas Android nuevas no se ejecutaron aquí; no se contabilizan como aprobadas.
